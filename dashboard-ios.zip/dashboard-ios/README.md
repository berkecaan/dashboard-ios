# Dashboard (iOS)

iPhone için yatay, premium araç paneli: MapKit navigasyon, Spotify, WeatherKit, GPS hız göstergesi.
Swift 6 · SwiftUI · MVVM · iOS 26+ · Liquid Glass.

> **Durum:** Kod Linux ortamında yazıldı; **Xcode ile derlenmedi/test edilmedi.**
> İlk derleme hataları çıkabilir. Doğrulama için GitHub Actions "Unsigned build check" işini çalıştırın.

## Kurulum

```bash
brew install xcodegen
xcodegen generate        # Dashboard.xcodeproj üretir (repoda tutulmaz)
open Dashboard.xcodeproj
```

Xcode 26+ gerekir. Signing & Capabilities'ta kendi Team'inizi seçin, bundle id'yi gerekirse değiştirin
(`project.yml` → `PRODUCT_BUNDLE_IDENTIFIER`; imzalı CI için `ios-build.yml` içindeki
`ExportOptions` bundle id'sini de güncelleyin).

## WeatherKit
1. Apple Developer Program üyeliği gerekir.
2. developer.apple.com → Identifiers → App ID'nizde **WeatherKit** hizmetini etkinleştirin.
3. Xcode → Signing & Capabilities → **+ Capability → WeatherKit** (entitlement dosyada hazır).
4. Etkinleştirme sonrası birkaç dakika bekleyin; imzasız derlemede WeatherKit çalışmaz.

## Spotify
1. developer.spotify.com/dashboard → uygulama oluşturun, **Redirect URI** olarak `dashboard-spotify://callback` ekleyin.
2. Client ID'yi uygulamada **Ayarlar → Spotify Client ID**'ye girin (veya derlemede `SPOTIFY_CLIENT_ID` build ayarı).
3. "Spotify'a Bağlan" → OAuth Authorization Code + PKCE. Tokenlar Keychain'de saklanır, otomatik yenilenir.
4. Development modundaki Spotify uygulamasında kullanıcı e-postanızı "User Management"e eklemeniz gerekir.

Sınırlar: oynatma kontrolü (oynat/duraklat/sonraki/önceki/seek) **Spotify Premium** ve **aktif bir cihaz** (Spotify uygulaması açık) ister.
Dashboard sesi kendisi çalmaz; iPhone'daki Spotify veya başka bir cihazı uzaktan kontrol eder.

## Navigasyon — gerçek yetenekler ve sınırlar
- MapKit haritası uygulama içinde; canlı konum, trafik katmanı, adres/mekan arama, alternatif rotalar, rota çizimi, ETA.
- Dönüş talimatları `MKRoute.steps`'ten gösterilir; sesli yönlendirme `AVSpeechSynthesizer` ile **kendi uygulamamızdadır** (Apple Maps'in tam navigasyon motoru değildir).
- Adım takibi ve rotadan sapınca yeniden hesaplama basit mesafe tabanlıdır; şerit önerisi, hız limiti uyarısı, trafiğe göre canlı yeniden rota yoktur.
- Arka planda konum/navigasyon için `UIBackgroundModes: location` eklenmedi; uygulama ekranda açık kullanım için tasarlandı.

## GitHub Actions
`.github/workflows/ios-build.yml`
- **build-unsigned**: macOS runner'da XcodeGen + imzasız `xcodebuild`.
- **build-signed**: aşağıdaki secret'lar tanımlıysa imzalı IPA üretir ve `Dashboard-ipa` artifact'i olarak yükler; yoksa atlanır.

| Secret | İçerik |
|---|---|
| `IOS_CERT_P12_BASE64` | `base64 -i cert.p12` çıktısı |
| `IOS_CERT_PASSWORD` | .p12 parolası |
| `IOS_PROVISION_PROFILE_BASE64` | `base64 -i profile.mobileprovision` |
| `IOS_TEAM_ID` | Apple Team ID |

Opsiyonel repo değişkenleri: `IOS_SIGN_IDENTITY` (varsayılan `Apple Distribution`), `IOS_EXPORT_METHOD` (varsayılan `ad-hoc`).
Provisioning profile, WeatherKit capability'li App ID'ye ait olmalı. Sertifika/token/anahtar kaynak koda gömülmez.

## Yapı
```
Dashboard/App        giriş noktası
Dashboard/Core       Keychain, ayarlar, favoriler, tema, ağ durumu
Dashboard/Features   Navigation · Spotify · Weather · Vehicle(Location) · Dashboard
```
